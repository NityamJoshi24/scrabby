import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      default:
        throw UnsupportedError('Unsupported platform');
    }
  }

  // Pull these values from your google-services.json
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyDkAKpHEeTkkhFau0som9ag176_hXpHOkk',               // client[0].api_key[0].current_key
    appId: '1:516233644956:android:3ec2dc2aa6fe393b721659',                 // client[0].client_info.mobilesdk_app_id
    messagingSenderId: '516233644956',  // project_info.project_number
    projectId: 'scrabble-online-7a022',         // project_info.project_id
    storageBucket: 'scrabble-online-7a022.appspot.com', // project_info.storage_bucket
  );
}